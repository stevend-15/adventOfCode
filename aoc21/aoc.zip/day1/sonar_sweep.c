#include <stdio.h>
#include <stdlib.h>
#include <string.h>


 int main() {

     int x = 0;
     int y = 0;

     int measurements[] = {199, 200, 208, 210, 200, 207, 240, 269, 260, 263, '\0'};
     
     int sizeM = (sizeof(measurements)/sizeof(measurements[0]));
     printf("size of measurements is: %d\n", sizeM);

     int *arrPtr;
     arrPtr = measurements;

     for (int i=0; i<sizeM; i++) {
         printf("%d \n", measurements[i]);
     }
    
     printf("\n\n\n");

     for (arrPtr; *arrPtr!='\0'; arrPtr++) {
         printf("%d \n", *arrPtr);

     }

     return 0;
    

}

